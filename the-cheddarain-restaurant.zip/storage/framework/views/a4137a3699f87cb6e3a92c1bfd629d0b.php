<?php $__env->startSection('title', 'Manage Orders — The Cheddarain Admin'); ?>

<?php $__env->startSection('admin_content'); ?>
<div>
    <div style="display: flex; justify-content: space-between; align-items: center; margin-bottom: 2rem; flex-wrap: wrap; gap: 1rem;">
        <div>
            <h1 style="font-size: 2rem; margin-bottom: 0.3rem;">Order Management</h1>
            <p style="color: var(--text-cream-muted); font-size: 0.95rem;">Filter, search, inspect, and update customer orders.</p>
        </div>
    </div>

    <!-- Filters & Search Form -->
    <div style="background: var(--bg-card); border: 1px solid var(--border-subtle); border-radius: var(--radius-lg); padding: 1.5rem; margin-bottom: 2rem;">
        <form action="<?php echo e(route('admin.orders.index')); ?>" method="GET" style="display: grid; grid-template-columns: repeat(auto-fit, minmax(200px, 1fr)) 100px; gap: 1rem; align-items: end;">
            <div class="form-group" style="margin-bottom: 0;">
                <label class="form-label" for="search">Search</label>
                <input type="text" name="search" id="search" class="form-input" placeholder="Ref, Name, Phone..." value="<?php echo e(request('search')); ?>">
            </div>

            <div class="form-group" style="margin-bottom: 0;">
                <label class="form-label" for="status">Status</label>
                <select name="status" id="status" class="form-select">
                    <?php $__currentLoopData = $statuses; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $value => $label): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <option value="<?php echo e($value); ?>" <?php echo e(request('status') === $value ? 'selected' : ''); ?>><?php echo e($label); ?></option>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </select>
            </div>

            <div class="form-group" style="margin-bottom: 0;">
                <label class="form-label" for="date">Order Date</label>
                <input type="date" name="date" id="date" class="form-input" value="<?php echo e(request('date')); ?>">
            </div>

            <div>
                <button type="submit" class="btn btn-primary btn-block" style="padding: 0.85rem;">
                    <span>Filter</span>
                </button>
            </div>
        </form>
    </div>

    <!-- Orders Table -->
    <div class="data-table-wrapper">
        <table class="data-table">
            <thead>
                <tr>
                    <th>Ref #</th>
                    <th>Customer</th>
                    <th>Fulfillment</th>
                    <th>Items</th>
                    <th>Total</th>
                    <th>Payment</th>
                    <th>Status</th>
                    <th>Date & Time</th>
                    <th>Actions</th>
                </tr>
            </thead>
            <tbody>
                <?php $__empty_1 = true; $__currentLoopData = $orders; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $order): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                    <tr>
                        <td>
                            <strong style="color: var(--cheddar-bright); font-family: var(--font-heading);">
                                #<?php echo e($order->order_reference); ?>

                            </strong>
                        </td>
                        <td>
                            <div style="font-weight: 600;"><?php echo e($order->customer_name); ?></div>
                            <div style="font-size: 0.78rem; color: var(--text-cream-muted);">📞 <?php echo e($order->customer_phone); ?></div>
                        </td>
                        <td>
                            <span class="badge <?php echo e($order->fulfillment_type === 'pickup' ? 'badge-gold' : 'badge-cheddar'); ?>">
                                <?php echo e(ucfirst($order->fulfillment_type)); ?>

                            </span>
                        </td>
                        <td style="font-size: 0.88rem;"><?php echo e($order->items->sum('quantity')); ?> items</td>
                        <td style="font-weight: 700; color: var(--gold-bright);">$<?php echo e(number_format($order->total, 2)); ?></td>
                        <td>
                            <span style="font-size: 0.82rem; text-transform: uppercase; color: <?php echo e($order->payment_status === 'paid' ? 'var(--success)' : 'var(--warning)'); ?>;">
                                <?php echo e($order->payment_method); ?> (<?php echo e($order->payment_status); ?>)
                            </span>
                        </td>
                        <td>
                            <span class="badge <?php echo e($order->status === 'delivered' ? 'badge-success' : ($order->status === 'cancelled' ? 'badge-danger' : 'badge-cheddar')); ?>">
                                <?php echo e($order->status_label); ?>

                            </span>
                        </td>
                        <td style="font-size: 0.85rem; color: var(--text-cream-muted);">
                            <?php echo e($order->created_at->format('M d, Y')); ?><br>
                            <span style="font-size: 0.78rem; color: var(--text-dim);"><?php echo e($order->created_at->format('h:i A')); ?></span>
                        </td>
                        <td>
                            <a href="<?php echo e(route('admin.orders.show', $order->id)); ?>" class="btn btn-secondary btn-sm">
                                Manage &rarr;
                            </a>
                        </td>
                    </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                    <tr>
                        <td colspan="9" style="text-align: center; padding: 3rem; color: var(--text-cream-muted);">
                            No orders found matching the selected criteria.
                        </td>
                    </tr>
                <?php endif; ?>
            </tbody>
        </table>
    </div>

    <div style="margin-top: 1.5rem;">
        <?php echo e($orders->links()); ?>

    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\Users\Temeb\Desktop\lamri\resources\views/admin/orders/index.blade.php ENDPATH**/ ?>