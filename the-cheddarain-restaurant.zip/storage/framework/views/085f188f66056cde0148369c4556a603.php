<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">
    <title><?php echo $__env->yieldContent('title', 'Admin Portal — The Cheddarain'); ?></title>

    <!-- Google Fonts -->
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700&family=Plus+Jakarta+Sans:wght@600;700;800&display=swap" rel="stylesheet">

    <!-- Styles -->
    <link rel="stylesheet" href="<?php echo e(asset('css/theme.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('css/components.css')); ?>">
    <?php echo $__env->yieldPushContent('styles'); ?>
</head>
<body style="background: var(--bg-base);">

    <div class="admin-shell">
        <!-- Sidebar Navigation -->
        <aside class="admin-sidebar">
            <a href="<?php echo e(route('admin.dashboard')); ?>" class="brand-logo" style="margin-bottom: 2rem;">
                <div class="brand-icon">🧀</div>
                <div class="brand-text">Cheddar<span>Admin</span></div>
            </a>

            <div style="font-size: 0.78rem; text-transform: uppercase; letter-spacing: 0.08em; color: var(--text-dim); margin-bottom: 0.6rem;">
                Management Portal
            </div>

            <ul class="admin-sidebar-nav">
                <li class="admin-nav-item <?php echo e(request()->routeIs('admin.dashboard*') ? 'active' : ''); ?>">
                    <a href="<?php echo e(route('admin.dashboard')); ?>">
                        <span>📊</span>
                        <span>Dashboard</span>
                    </a>
                </li>

                <li class="admin-nav-item <?php echo e(request()->routeIs('admin.orders*') ? 'active' : ''); ?>">
                    <a href="<?php echo e(route('admin.orders.index')); ?>">
                        <span>📦</span>
                        <span>Order Manager</span>
                    </a>
                </li>

                <li class="admin-nav-item <?php echo e(request()->routeIs('admin.products*') ? 'active' : ''); ?>">
                    <a href="<?php echo e(route('admin.products.index')); ?>">
                        <span>🍔</span>
                        <span>Menu & Products</span>
                    </a>
                </li>

                <li class="admin-nav-item <?php echo e(request()->routeIs('admin.settings*') ? 'active' : ''); ?>">
                    <a href="<?php echo e(route('admin.settings.index')); ?>">
                        <span>⚙️</span>
                        <span>Store Settings</span>
                    </a>
                </li>

                <li class="admin-nav-item" style="margin-top: 2rem; border-top: 1px solid var(--border-subtle); padding-top: 1.5rem;">
                    <a href="<?php echo e(route('home')); ?>" target="_blank">
                        <span>🌐</span>
                        <span>View Customer Site &rarr;</span>
                    </a>
                </li>
            </ul>

            <!-- Staff User Badge & Logout -->
            <div style="padding-top: 1.5rem; border-top: 1px solid var(--border-subtle); margin-top: auto;">
                <div style="display: flex; align-items: center; justify-content: space-between; margin-bottom: 0.8rem;">
                    <div>
                        <div style="font-weight: 700; color: var(--text-cream); font-size: 0.9rem;"><?php echo e(auth()->user()->name ?? 'Staff User'); ?></div>
                        <div style="font-size: 0.75rem; color: var(--cheddar-bright); text-transform: uppercase;"><?php echo e(auth()->user()->role ?? 'Admin'); ?></div>
                    </div>
                </div>

                <form action="<?php echo e(route('admin.logout')); ?>" method="POST">
                    <?php echo csrf_field(); ?>
                    <button type="submit" class="btn btn-secondary btn-sm btn-block" style="font-size: 0.82rem;">
                        <span>Sign Out</span>
                    </button>
                </form>
            </div>
        </aside>

        <!-- Main Content Area -->
        <main class="admin-content">
            <?php if(session('success')): ?>
                <div class="alert alert-success">
                    <span>✓</span>
                    <span><?php echo e(session('success')); ?></span>
                </div>
            <?php endif; ?>

            <?php if(session('error')): ?>
                <div class="alert alert-danger">
                    <span>✕</span>
                    <span><?php echo e(session('error')); ?></span>
                </div>
            <?php endif; ?>

            <?php echo $__env->yieldContent('admin_content'); ?>
        </main>
    </div>

    <?php echo $__env->yieldPushContent('scripts'); ?>
</body>
</html>
<?php /**PATH C:\Users\Temeb\Desktop\lamri\resources\views/layouts/admin.blade.php ENDPATH**/ ?>