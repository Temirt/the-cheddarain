<?php $__env->startSection('title', 'Edit ' . $product->name . ' — The Cheddarain Admin'); ?>

<?php $__env->startSection('admin_content'); ?>
<div style="max-width: 800px;">
    <div style="margin-bottom: 2rem;">
        <h1 style="font-size: 2rem; margin-bottom: 0.3rem;">Edit: <?php echo e($product->name); ?></h1>
        <p style="color: var(--text-cream-muted); font-size: 0.95rem;">Update pricing, description, imagery, or availability.</p>
    </div>

    <?php if($errors->any()): ?>
        <div class="alert alert-danger" style="margin-bottom: 1.5rem;">
            <span>✕</span>
            <span><?php echo e($errors->first()); ?></span>
        </div>
    <?php endif; ?>

    <div style="background: var(--bg-card); border: 1px solid var(--border-subtle); border-radius: var(--radius-lg); padding: 2.2rem;">
        <form action="<?php echo e(route('admin.products.update', $product->id)); ?>" method="POST">
            <?php echo csrf_field(); ?>
            <?php echo method_field('PUT'); ?>

            <div style="display: grid; grid-template-columns: 1fr 1fr; gap: 1.2rem;">
                <div class="form-group" style="grid-column: 1 / -1;">
                    <label class="form-label" for="name">Product Name *</label>
                    <input type="text" name="name" id="name" class="form-input" required value="<?php echo e(old('name', $product->name)); ?>">
                </div>

                <div class="form-group">
                    <label class="form-label" for="category_id">Category *</label>
                    <select name="category_id" id="category_id" class="form-select" required>
                        <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <option value="<?php echo e($category->id); ?>" <?php echo e(old('category_id', $product->category_id) == $category->id ? 'selected' : ''); ?>>
                                <?php echo e($category->name); ?>

                            </option>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </select>
                </div>

                <div class="form-group">
                    <label class="form-label" for="price">Price ($) *</label>
                    <input type="number" step="0.01" name="price" id="price" class="form-input" required value="<?php echo e(old('price', $product->price)); ?>">
                </div>

                <div class="form-group" style="grid-column: 1 / -1;">
                    <label class="form-label" for="description">Product Description *</label>
                    <textarea name="description" id="description" class="form-textarea" required><?php echo e(old('description', $product->description)); ?></textarea>
                </div>

                <div class="form-group" style="grid-column: 1 / -1;">
                    <label class="form-label" for="image_url">Image URL</label>
                    <input type="url" name="image_url" id="image_url" class="form-input" value="<?php echo e(old('image_url', $product->image_url)); ?>">
                </div>

                <div class="form-group">
                    <label class="form-label" for="badge">Promo Badge (Optional)</label>
                    <input type="text" name="badge" id="badge" class="form-input" value="<?php echo e(old('badge', $product->badge)); ?>">
                </div>

                <div class="form-group">
                    <label class="form-label" for="calories">Calories (kcal)</label>
                    <input type="number" name="calories" id="calories" class="form-input" value="<?php echo e(old('calories', $product->calories)); ?>">
                </div>

                <div class="form-group">
                    <label class="form-label" for="prep_time_minutes">Kitchen Prep Time (Minutes) *</label>
                    <input type="number" name="prep_time_minutes" id="prep_time_minutes" class="form-input" required value="<?php echo e(old('prep_time_minutes', $product->prep_time_minutes)); ?>">
                </div>

                <div class="form-group" style="display: flex; flex-direction: column; justify-content: center;">
                    <label style="display: flex; align-items: center; gap: 0.6rem; cursor: pointer; margin-top: 1.2rem;">
                        <input type="checkbox" name="is_featured" value="1" <?php echo e(old('is_featured', $product->is_featured) ? 'checked' : ''); ?> style="accent-color: var(--cheddar-bright);">
                        <span>Featured on Homepage</span>
                    </label>

                    <label style="display: flex; align-items: center; gap: 0.6rem; cursor: pointer; margin-top: 0.8rem;">
                        <input type="checkbox" name="is_available" value="1" <?php echo e(old('is_available', $product->is_available) ? 'checked' : ''); ?> style="accent-color: var(--cheddar-bright);">
                        <span>Available for Order</span>
                    </label>
                </div>
            </div>

            <div style="display: flex; gap: 1rem; margin-top: 2rem; padding-top: 1.5rem; border-top: 1px solid var(--border-subtle);">
                <button type="submit" class="btn btn-primary btn-lg">
                    <span>Save Changes &rarr;</span>
                </button>
                <a href="<?php echo e(route('admin.products.index')); ?>" class="btn btn-secondary btn-lg">Cancel</a>
            </div>
        </form>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\Users\Temeb\Desktop\lamri\resources\views/admin/products/edit.blade.php ENDPATH**/ ?>