<?php $__env->startSection('title', 'Menu Products — The Cheddarain Admin'); ?>

<?php $__env->startSection('admin_content'); ?>
<div>
    <div style="display: flex; justify-content: space-between; align-items: center; margin-bottom: 2rem; flex-wrap: wrap; gap: 1rem;">
        <div>
            <h1 style="font-size: 2rem; margin-bottom: 0.3rem;">Menu & Products</h1>
            <p style="color: var(--text-cream-muted); font-size: 0.95rem;">Manage burger creations, loaded sides, signature sauces, and availability.</p>
        </div>

        <a href="<?php echo e(route('admin.products.create')); ?>" class="btn btn-primary btn-sm">
            <span>+ Add New Product</span>
        </a>
    </div>

    <div class="data-table-wrapper">
        <table class="data-table">
            <thead>
                <tr>
                    <th>Item</th>
                    <th>Category</th>
                    <th>Price</th>
                    <th>Calories</th>
                    <th>Prep Time</th>
                    <th>Status</th>
                    <th>Actions</th>
                </tr>
            </thead>
            <tbody>
                <?php $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <td>
                            <div style="display: flex; align-items: center; gap: 1rem;">
                                <img src="<?php echo e($product->image_url); ?>" alt="<?php echo e($product->name); ?>" style="width: 50px; height: 50px; border-radius: var(--radius-sm); object-fit: cover; background: var(--bg-surface);">
                                <div>
                                    <strong style="color: var(--text-cream); display: block;"><?php echo e($product->name); ?></strong>
                                    <?php if($product->badge): ?>
                                        <span class="badge badge-cheddar" style="font-size: 0.68rem;"><?php echo e($product->badge); ?></span>
                                    <?php endif; ?>
                                </div>
                            </div>
                        </td>
                        <td>
                            <span class="badge badge-gold"><?php echo e($product->category->name ?? 'General'); ?></span>
                        </td>
                        <td style="font-weight: 700; color: var(--gold-bright); font-size: 1.05rem;">
                            $<?php echo e(number_format($product->price, 2)); ?>

                        </td>
                        <td style="font-size: 0.88rem; color: var(--text-cream-muted);">
                            <?php echo e($product->calories ? $product->calories . ' kcal' : '—'); ?>

                        </td>
                        <td style="font-size: 0.88rem;">
                            <?php echo e($product->prep_time_minutes); ?> mins
                        </td>
                        <td>
                            <form action="<?php echo e(route('admin.products.toggle', $product->id)); ?>" method="POST">
                                <?php echo csrf_field(); ?>
                                <button type="submit" class="badge <?php echo e($product->is_available ? 'badge-success' : 'badge-danger'); ?>" style="cursor: pointer; border: none;">
                                    <?php echo e($product->is_available ? 'Available' : 'Out of Stock'); ?>

                                </button>
                            </form>
                        </td>
                        <td>
                            <div style="display: flex; gap: 0.5rem;">
                                <a href="<?php echo e(route('admin.products.edit', $product->id)); ?>" class="btn btn-secondary btn-sm" style="padding: 0.35rem 0.75rem;">
                                    Edit
                                </a>
                                <form action="<?php echo e(route('admin.products.destroy', $product->id)); ?>" method="POST" onsubmit="return confirm('Delete this menu item?');">
                                    <?php echo csrf_field(); ?>
                                    <?php echo method_field('DELETE'); ?>
                                    <button type="submit" class="btn btn-secondary btn-sm" style="padding: 0.35rem 0.75rem; color: var(--danger);">
                                        ✕
                                    </button>
                                </form>
                            </div>
                        </td>
                    </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>
        </table>
    </div>

    <div style="margin-top: 1.5rem;">
        <?php echo e($products->links()); ?>

    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\Users\Temeb\Desktop\lamri\resources\views/admin/products/index.blade.php ENDPATH**/ ?>