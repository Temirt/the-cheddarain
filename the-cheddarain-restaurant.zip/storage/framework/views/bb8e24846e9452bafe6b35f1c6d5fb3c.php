<?php $__env->startSection('title', 'My Account — The Cheddarain'); ?>

<?php $__env->startSection('content'); ?>
<div class="container" style="padding-top: 3.5rem; padding-bottom: 5rem;">
    <div class="section-title">
        <span class="badge badge-cheddar">Customer Portal</span>
        <h2>Welcome, <?php echo e($user->name); ?></h2>
        <p>Manage your account details and track your past and active orders.</p>
    </div>

    <div style="display: grid; grid-template-columns: 0.8fr 1.2fr; gap: 2.5rem; align-items: start;">
        <!-- Profile Card -->
        <div style="background: var(--bg-card); border: 1px solid var(--border-subtle); border-radius: var(--radius-xl); padding: 2.2rem; box-shadow: var(--shadow-md);">
            <div style="display: flex; align-items: center; gap: 1rem; margin-bottom: 1.5rem; padding-bottom: 1.2rem; border-bottom: 1px solid var(--border-subtle);">
                <div style="width: 56px; height: 56px; border-radius: var(--radius-full); background: var(--cheddar-gradient); color: #000; font-size: 1.5rem; font-weight: 800; display: flex; align-items: center; justify-content: center; box-shadow: 0 4px 14px var(--cheddar-glow);">
                    <?php echo e(strtoupper(substr($user->name, 0, 1))); ?>

                </div>
                <div>
                    <h3 style="font-size: 1.25rem; color: var(--text-cream); margin-bottom: 0.2rem;"><?php echo e($user->name); ?></h3>
                    <span class="badge badge-gold" style="font-size: 0.72rem;">Customer Member</span>
                </div>
            </div>

            <div style="display: flex; flex-direction: column; gap: 1rem; font-size: 0.92rem; margin-bottom: 2rem;">
                <div>
                    <span style="color: var(--text-cream-muted); display: block; font-size: 0.8rem; text-transform: uppercase;">Email Address</span>
                    <strong style="color: var(--text-cream);"><?php echo e($user->email); ?></strong>
                </div>

                <div>
                    <span style="color: var(--text-cream-muted); display: block; font-size: 0.8rem; text-transform: uppercase;">Phone Number</span>
                    <strong style="color: var(--text-cream);"><?php echo e($user->phone ?? 'Not provided'); ?></strong>
                </div>

                <div>
                    <span style="color: var(--text-cream-muted); display: block; font-size: 0.8rem; text-transform: uppercase;">Member Since</span>
                    <span style="color: var(--text-cream-soft);"><?php echo e($user->created_at->format('F d, Y')); ?></span>
                </div>
            </div>

            <div style="display: flex; flex-direction: column; gap: 0.8rem;">
                <a href="<?php echo e(route('menu')); ?>" class="btn btn-primary btn-block">
                    <span>🍔 Order Food Now</span>
                </a>

                <form action="<?php echo e(route('logout')); ?>" method="POST">
                    <?php echo csrf_field(); ?>
                    <button type="submit" class="btn btn-secondary btn-block">
                        <span>Sign Out</span>
                    </button>
                </form>
            </div>
        </div>

        <!-- Orders & Live Tracking List -->
        <div>
            <div style="background: var(--bg-card); border: 1px solid var(--border-subtle); border-radius: var(--radius-xl); padding: 2.2rem; box-shadow: var(--shadow-md);">
                <div style="display: flex; justify-content: space-between; align-items: center; margin-bottom: 1.5rem; padding-bottom: 0.8rem; border-bottom: 1px solid var(--border-subtle);">
                    <h3 style="font-size: 1.25rem; color: var(--text-cream); display: flex; align-items: center; gap: 0.5rem;">
                        <span>📦</span> My Orders & Live Tracking (<?php echo e($orders->count()); ?>)
                    </h3>
                </div>

                <?php $__empty_1 = true; $__currentLoopData = $orders; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $order): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                    <div style="background: var(--bg-surface); border: 1px solid var(--border-subtle); border-radius: var(--radius-lg); padding: 1.5rem; margin-bottom: 1.2rem; transition: border-color 0.2s ease;">
                        <div style="display: flex; justify-content: space-between; align-items: start; margin-bottom: 0.8rem; flex-wrap: wrap; gap: 0.5rem;">
                            <div>
                                <span style="font-size: 0.8rem; text-transform: uppercase; color: var(--text-cream-muted); letter-spacing: 0.05em;">Order Reference</span>
                                <div style="font-family: var(--font-heading); font-size: 1.35rem; font-weight: 800; color: var(--cheddar-bright);">
                                    #<?php echo e($order->order_reference); ?>

                                </div>
                                <span style="font-size: 0.82rem; color: var(--text-dim);"><?php echo e($order->created_at->format('M d, Y \a\t h:i A')); ?> (<?php echo e($order->created_at->diffForHumans()); ?>)</span>
                            </div>

                            <div style="text-align: right;">
                                <span class="badge <?php echo e($order->status === 'delivered' ? 'badge-success' : ($order->status === 'cancelled' ? 'badge-danger' : 'badge-cheddar')); ?>" style="font-size: 0.8rem;">
                                    <?php echo e($order->status_label); ?>

                                </span>
                                <div style="font-family: var(--font-heading); font-size: 1.3rem; font-weight: 800; color: var(--gold-bright); margin-top: 0.4rem;">
                                    $<?php echo e(number_format($order->total, 2)); ?>

                                </div>
                            </div>
                        </div>

                        <!-- Item summary -->
                        <div style="font-size: 0.88rem; color: var(--text-cream-muted); margin-bottom: 1.2rem; padding: 0.6rem 0; border-top: 1px dashed var(--border-subtle); border-bottom: 1px dashed var(--border-subtle);">
                            <?php $__currentLoopData = $order->items; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <span><?php echo e($item->quantity); ?>x <?php echo e($item->product_name); ?><?php if(!$loop->last): ?>, <?php endif; ?></span>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            <div style="font-size: 0.82rem; color: var(--gold-bright); margin-top: 0.4rem;">
                                💵 Pay in person with Order ID #<?php echo e($order->order_reference); ?> • <?php echo e(ucfirst($order->fulfillment_type)); ?>

                            </div>
                        </div>

                        <!-- Action buttons -->
                        <div style="display: flex; gap: 0.8rem; align-items: center; justify-content: flex-end; flex-wrap: wrap;">
                            <a href="<?php echo e($order->whatsapp_link); ?>" target="_blank" rel="noopener noreferrer" class="btn btn-secondary btn-sm" style="font-size: 0.82rem;">
                                <span>💬 WhatsApp Enquiry</span>
                            </a>
                            <a href="<?php echo e(route('order.track.show', $order->order_reference)); ?>" class="btn btn-primary btn-sm">
                                <span>📍 Track Live Progress &rarr;</span>
                            </a>
                        </div>
                    </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                    <div style="text-align: center; padding: 3rem 1rem;">
                        <div style="font-size: 3rem; margin-bottom: 1rem;">🍔</div>
                        <h4>No Orders Found</h4>
                        <p style="color: var(--text-cream-muted); font-size: 0.95rem; margin-bottom: 1.5rem;">You haven't placed an order yet. Treat yourself to our double-melted cheddar burgers!</p>
                        <a href="<?php echo e(route('menu')); ?>" class="btn btn-primary">Browse Artisan Menu</a>
                    </div>
                <?php endif; ?>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\Users\Temeb\Desktop\lamri\resources\views/pages/auth/account.blade.php ENDPATH**/ ?>