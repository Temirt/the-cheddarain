<?php $__env->startSection('title', 'Artisan Menu — The Cheddarloin'); ?>

<?php $__env->startSection('content'); ?>
<div class="container" style="padding-top: 3.5rem; padding-bottom: 5rem;">
    <div class="section-title">
        <span class="badge badge-cheddar">Fresh Daily Selection</span>
        <h2>Our Artisan Menu</h2>
        <p>Premium 100% Angus smash patties, loaded sides, hand-crafted dipping sauces, and feasts.</p>
    </div>

    <!-- Live Search Input -->
    <div class="menu-search-wrapper">
        <span class="menu-search-icon">🔍</span>
        <input type="text" id="menu-search-input" class="menu-search-input" placeholder="Search burgers, fries, or sauces..." value="<?php echo e($search); ?>">
    </div>

    <!-- Category Filters -->
    <div class="category-tabs">
        <a href="<?php echo e(route('menu', ['category' => 'all'])); ?>" class="category-tab-btn <?php echo e($selectedCategory === 'all' ? 'active' : ''); ?>">
            <span>🌟</span> All Items
        </a>
        <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cat): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <a href="<?php echo e(route('menu', ['category' => $cat->slug])); ?>" class="category-tab-btn <?php echo e($selectedCategory === $cat->slug ? 'active' : ''); ?>">
                <span><?php echo e($cat->icon ?? '🍔'); ?></span> <?php echo e($cat->name); ?>

            </a>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </div>

    <!-- Products Grid -->
    <div class="product-grid" id="product-grid">
        <?php $__empty_1 = true; $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
            <div class="product-card" data-category="<?php echo e($product->category->slug ?? ''); ?>">
                <a href="<?php echo e(route('product.detail', $product->slug)); ?>" class="product-image-container">
                    <img src="<?php echo e($product->image_url); ?>" alt="<?php echo e($product->name); ?>" loading="lazy">
                    <?php if($product->badge): ?>
                        <div class="product-badge-overlay">
                            <span class="badge badge-cheddar"><?php echo e($product->badge); ?></span>
                        </div>
                    <?php endif; ?>
                    <?php if($product->calories): ?>
                        <div class="product-calories-overlay">
                            🔥 <?php echo e($product->calories); ?> kcal
                        </div>
                    <?php endif; ?>
                </a>

                <div class="product-info">
                    <div class="product-category-name"><?php echo e($product->category->name ?? 'Menu'); ?></div>
                    <h3 class="product-title">
                        <a href="<?php echo e(route('product.detail', $product->slug)); ?>" style="color: inherit;"><?php echo e($product->name); ?></a>
                    </h3>
                    <p class="product-desc"><?php echo e($product->description); ?></p>

                    <div class="product-footer">
                        <div class="product-price"><?php echo e($product->formatted_price); ?></div>
                        <div style="display: flex; gap: 0.5rem; align-items: center;">
                            <?php if($product->options->count() > 0): ?>
                                <button type="button" class="btn btn-secondary btn-sm open-customize-btn" data-product-id="<?php echo e($product->id); ?>">
                                    <span>Customize</span>
                                </button>
                            <?php endif; ?>
                            <button type="button" class="btn-add"
                                    data-product-id="<?php echo e($product->id); ?>"
                                    data-product-name="<?php echo e($product->name); ?>"
                                    data-product-price="<?php echo e($product->price); ?>"
                                    data-product-image="<?php echo e($product->image_url); ?>"
                                    aria-label="Add <?php echo e($product->name); ?> to cart">
                                <span>Add +</span>
                            </button>
                        </div>
                    </div>
                </div>
            </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
            <div style="grid-column: 1 / -1; text-align: center; padding: 4rem 1rem;">
                <div style="font-size: 3rem; margin-bottom: 1rem;">🍔</div>
                <h3>No items found</h3>
                <p style="color: var(--text-cream-muted); margin-bottom: 1.5rem;">Try adjusting your search terms or filter selection.</p>
                <a href="<?php echo e(route('menu')); ?>" class="btn btn-secondary">View All Menu Items</a>
            </div>
        <?php endif; ?>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\Users\Temeb\Desktop\lamri\resources\views/pages/menu.blade.php ENDPATH**/ ?>