<?php $__env->startSection('title', 'Manage Categories — Admin Portal'); ?>

<?php $__env->startSection('admin_content'); ?>
    <div style="display: flex; justify-content: space-between; align-items: center; margin-bottom: 2rem; flex-wrap: wrap; gap: 1rem;">
        <div>
            <h1 style="font-size: 1.85rem; margin-bottom: 0.3rem;">Menu Categories</h1>
            <p style="color: var(--text-cream-muted); font-size: 0.95rem;">Organize your menu into categories (Burgers, Sides, Drinks, Meals, etc.).</p>
        </div>
        <a href="<?php echo e(route('admin.categories.create')); ?>" class="btn btn-primary">
            <span>+</span>
            <span>Add New Category</span>
        </a>
    </div>

    <div class="admin-table-container">
        <table class="admin-table">
            <thead>
                <tr>
                    <th>Order</th>
                    <th>Icon</th>
                    <th>Name</th>
                    <th>Slug</th>
                    <th>Products Count</th>
                    <th>Status</th>
                    <th style="text-align: right;">Actions</th>
                </tr>
            </thead>
            <tbody>
                <?php $__empty_1 = true; $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                    <tr>
                        <td style="font-weight: 700; color: var(--gold-bright);"><?php echo e($category->sort_order); ?></td>
                        <td style="font-size: 1.5rem;"><?php echo e($category->icon ?? '🍔'); ?></td>
                        <td>
                            <strong style="color: var(--text-cream);"><?php echo e($category->name); ?></strong>
                            <?php if($category->description): ?>
                                <div style="font-size: 0.8rem; color: var(--text-dim);"><?php echo e(Str::limit($category->description, 60)); ?></div>
                            <?php endif; ?>
                        </td>
                        <td><code style="background: rgba(255,255,255,0.06); padding: 0.2rem 0.5rem; border-radius: 4px; font-size: 0.85rem;"><?php echo e($category->slug); ?></code></td>
                        <td>
                            <span class="badge badge-gold"><?php echo e($category->products_count); ?> items</span>
                        </td>
                        <td>
                            <?php if($category->is_active): ?>
                                <span class="badge" style="background: rgba(111, 175, 117, 0.2); color: var(--success); border: 1px solid var(--success);">Active</span>
                            <?php else: ?>
                                <span class="badge" style="background: rgba(255, 255, 255, 0.1); color: var(--text-dim);">Hidden</span>
                            <?php endif; ?>
                        </td>
                        <td style="text-align: right;">
                            <div style="display: inline-flex; gap: 0.5rem;">
                                <a href="<?php echo e(route('admin.categories.edit', $category->id)); ?>" class="btn btn-secondary btn-sm" style="padding: 0.35rem 0.75rem;">
                                    Edit
                                </a>
                                <?php if($category->products_count === 0): ?>
                                    <form action="<?php echo e(route('admin.categories.destroy', $category->id)); ?>" method="POST" onsubmit="return confirm('Are you sure you want to delete this category?');" style="display: inline;">
                                        <?php echo csrf_field(); ?>
                                        <?php echo method_field('DELETE'); ?>
                                        <button type="submit" class="btn btn-danger btn-sm" style="padding: 0.35rem 0.75rem;">
                                            Delete
                                        </button>
                                    </form>
                                <?php endif; ?>
                            </div>
                        </td>
                    </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                    <tr>
                        <td colspan="7" style="text-align: center; padding: 3rem; color: var(--text-dim);">
                            No categories created yet. Click "+ Add New Category" above to create one.
                        </td>
                    </tr>
                <?php endif; ?>
            </tbody>
        </table>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\Users\Temeb\Desktop\lamri\resources\views/admin/categories/index.blade.php ENDPATH**/ ?>