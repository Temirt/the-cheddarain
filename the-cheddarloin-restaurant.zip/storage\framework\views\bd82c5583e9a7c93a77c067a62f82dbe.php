<?php $__env->startSection('title', 'Track Order #' . $order->order_reference . ' — The Cheddarloin'); ?>

<?php $__env->startSection('content'); ?>
<div class="container" style="padding-top: 3.5rem; padding-bottom: 5rem;">

    <?php if(!$isVerified): ?>
        <!-- Security Verification Step -->
        <div class="container-narrow" style="margin: 0 auto;">
            <div class="section-title">
                <span class="badge badge-warning">Customer Verification Required</span>
                <h2>Verify Your Order Access</h2>
                <p>For your privacy and security, please enter the phone number associated with order <strong>#<?php echo e($order->order_reference); ?></strong>.</p>
            </div>

            <?php if(isset($error)): ?>
                <div class="alert alert-danger" style="max-width: 520px; margin: 0 auto 1.5rem auto;">
                    <span>✕</span>
                    <span><?php echo e($error); ?></span>
                </div>
            <?php endif; ?>

            <div style="background: var(--bg-card); border: 1px solid var(--border-subtle); border-radius: var(--radius-xl); padding: 2.5rem; max-width: 520px; margin: 0 auto; box-shadow: var(--shadow-lg);">
                <form action="<?php echo e(route('order.track.verify', $order->order_reference)); ?>" method="POST">
                    <?php echo csrf_field(); ?>
                    <div class="form-group" style="margin-bottom: 1.5rem;">
                        <label class="form-label" for="verify_phone">Registered Phone Number</label>
                        <input type="tel" name="phone" id="verify_phone" class="form-input" placeholder="e.g. 555-123-4567 or last 4 digits" required autofocus>
                        <span class="form-hint">Enter the phone number you entered during checkout.</span>
                    </div>

                    <button type="submit" class="btn btn-primary btn-block btn-lg">
                        <span>Unlock Live Tracking Feed &rarr;</span>
                    </button>
                </form>

                <div style="text-align: center; margin-top: 1.5rem;">
                    <a href="<?php echo e(route('order.track')); ?>" style="font-size: 0.88rem; color: var(--text-cream-muted);">&larr; Look up a different order</a>
                </div>
            </div>
        </div>

    <?php else: ?>
        <!-- Full Verified McDonald's-Style Live Order Tracker -->
        <div class="order-tracker-card">
            <!-- Tracker Header -->
            <div class="tracker-header">
                <div class="tracker-ref-box">
                    <span class="tracker-ref-label">Live Order Tracking</span>
                    <span class="tracker-ref-number">#<?php echo e($order->order_reference); ?></span>
                    <span style="font-size: 0.85rem; color: var(--text-cream-muted);">
                        Placed on <?php echo e($order->created_at->format('M d, Y \a\t h:i A')); ?> • Customer: <strong><?php echo e($order->customer_name); ?></strong>
                    </span>
                </div>

                <div style="display: flex; align-items: center; gap: 1rem; flex-wrap: wrap;">
                    <div class="live-poll-indicator" id="live-poll-indicator">
                        <div class="pulse-dot"></div>
                        <span>Live Tracking Active</span>
                    </div>

                    <span style="font-size: 0.82rem; color: var(--text-cream-muted);" id="tracker-last-updated">
                        Updated <?php echo e($order->updated_at->diffForHumans()); ?>

                    </span>
                </div>
            </div>

            <!-- McDonald's 5-Step Visual Timeline -->
            <?php
                $step = $order->timeline_step;
                $stepPercentages = [1 => 15, 2 => 35, 3 => 65, 4 => 85, 5 => 100, 0 => 0];
                $percent = $stepPercentages[$step] ?? 15;
            ?>

            <div class="timeline-track-wrapper">
                <div class="timeline-progress-bar">
                    <div class="timeline-progress-fill" id="timeline-progress-fill" style="width: <?php echo e($percent); ?>%;"></div>
                </div>

                <ul class="timeline-steps">
                    <!-- Step 1: Order Placed -->
                    <li class="timeline-step <?php echo e($step > 1 ? 'completed' : ($step === 1 ? 'active' : '')); ?>" id="timeline-step-1">
                        <div class="step-circle">
                            <?php if($step > 1): ?> ✓ <?php else: ?> 📝 <?php endif; ?>
                        </div>
                        <div class="step-label">Order Placed</div>
                        <div class="step-subtext">Received</div>
                    </li>

                    <!-- Step 2: Order Confirmed -->
                    <li class="timeline-step <?php echo e($step > 2 ? 'completed' : ($step === 2 ? 'active' : '')); ?>" id="timeline-step-2">
                        <div class="step-circle">
                            <?php if($step > 2): ?> ✓ <?php else: ?> 👨‍🍳 <?php endif; ?>
                        </div>
                        <div class="step-label">Order Confirmed</div>
                        <div class="step-subtext">Kitchen Accepted</div>
                    </li>

                    <!-- Step 3: Preparing Food -->
                    <li class="timeline-step <?php echo e($step > 3 ? 'completed' : ($step === 3 ? 'active' : '')); ?>" id="timeline-step-3">
                        <div class="step-circle">
                            <?php if($step > 3): ?> ✓ <?php else: ?> 🍔 <?php endif; ?>
                        </div>
                        <div class="step-label">Preparing Food</div>
                        <div class="step-subtext">Smashing & Melting</div>
                    </li>

                    <!-- Step 4: Ready for Pickup or Out for Delivery -->
                    <li class="timeline-step <?php echo e($step > 4 ? 'completed' : ($step === 4 ? 'active' : '')); ?>" id="timeline-step-4">
                        <div class="step-circle">
                            <?php if($step > 4): ?> ✓ <?php else: ?> <?php echo e($order->fulfillment_type === 'pickup' ? '🛍️' : '🛵'); ?> <?php endif; ?>
                        </div>
                        <div class="step-label" id="step-4-label">
                            <?php echo e($order->fulfillment_type === 'pickup' ? 'Ready for Pickup' : 'Out for Delivery'); ?>

                        </div>
                        <div class="step-subtext">Hot & Fresh</div>
                    </li>

                    <!-- Step 5: Delivered / Completed -->
                    <li class="timeline-step <?php echo e($step === 5 ? 'completed active' : ''); ?>" id="timeline-step-5">
                        <div class="step-circle">
                            🎉
                        </div>
                        <div class="step-label">Delivered</div>
                        <div class="step-subtext">Enjoy Your Meal</div>
                    </li>
                </ul>
            </div>

            <!-- Status Headline & Countdown Banner -->
            <div class="tracker-status-banner">
                <div class="status-headline">
                    <div class="status-icon-large">
                        <?php if($order->status === 'cancelled'): ?>
                            ❌
                        <?php elseif($order->status === 'delivered'): ?>
                            🎉
                        <?php elseif($order->status === 'ready_for_pickup'): ?>
                            🛍️
                        <?php elseif($order->status === 'out_for_delivery'): ?>
                            🛵
                        <?php elseif($order->status === 'preparing'): ?>
                            🍔
                        <?php else: ?>
                            👨‍🍳
                        <?php endif; ?>
                    </div>
                    <div class="status-headline-text">
                        <h3 id="tracker-status-headline"><?php echo e($order->status_label); ?></h3>
                        <p id="tracker-status-desc">
                            <?php if($order->status === 'pending'): ?>
                                We have received your order. The kitchen will review and confirm shortly.
                            <?php elseif($order->status === 'confirmed'): ?>
                                Your order is confirmed! Chefs are queuing up your artisanal cheddar feast.
                            <?php elseif($order->status === 'preparing'): ?>
                                Cooking fresh right now! Patties sizzling and cheddar lava dripping.
                            <?php elseif($order->status === 'ready_for_pickup'): ?>
                                Your order is bagged and waiting hot at the counter. Show order #<?php echo e($order->order_reference); ?> at pickup!
                            <?php elseif($order->status === 'out_for_delivery'): ?>
                                Our delivery driver is en route with your piping hot order!
                            <?php elseif($order->status === 'delivered'): ?>
                                Delivered! We hope you loved every bite of The Cheddarloin experience.
                            <?php elseif($order->status === 'cancelled'): ?>
                                Order was cancelled. Reason: <?php echo e($order->cancellation_reason ?? 'Restaurant closed/capacity'); ?>. Contact support below.
                            <?php endif; ?>
                        </p>
                    </div>
                </div>

                <div class="tracker-time-countdown">
                    <div class="countdown-label">Estimated Wait</div>
                    <div class="countdown-value" id="tracker-countdown-value">
                        <?php if($order->status === 'preparing' && $order->estimated_prep_minutes): ?>
                            ~<?php echo e($order->estimated_prep_minutes); ?> mins
                        <?php elseif($order->status === 'ready_for_pickup'): ?>
                            READY NOW
                        <?php elseif($order->status === 'out_for_delivery'): ?>
                            ON THE WAY
                        <?php elseif($order->status === 'delivered'): ?>
                            COMPLETED
                        <?php elseif($order->status === 'cancelled'): ?>
                            CANCELLED
                        <?php else: ?>
                            12-15 mins
                        <?php endif; ?>
                    </div>
                </div>
            </div>
        </div>

        <!-- Order Summary & Audit History Grid -->
        <div class="tracker-details-grid">
            <!-- Left Panel: Itemized Order Details -->
            <div class="tracker-card-panel">
                <h3><span>🧾</span> Order Breakdown</h3>

                <div style="display: flex; flex-direction: column; gap: 1rem; margin-bottom: 1.5rem;">
                    <?php $__currentLoopData = $order->items; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <div style="display: flex; justify-content: space-between; align-items: start; padding-bottom: 0.8rem; border-bottom: 1px solid var(--border-subtle);">
                            <div>
                                <strong style="color: var(--text-cream); font-size: 1.05rem;"><?php echo e($item->quantity); ?>x <?php echo e($item->product_name); ?></strong>
                                <?php if($item->selected_options && count($item->selected_options) > 0): ?>
                                    <div style="font-size: 0.85rem; color: var(--text-cream-muted); margin-top: 0.2rem;">
                                        <?php $__currentLoopData = $item->selected_options; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $opt): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <span class="badge badge-gold" style="font-size: 0.7rem; margin-right: 0.3rem;">
                                                <?php echo e($opt['choice']); ?> <?php echo e($opt['price'] > 0 ? '(+' . number_format($opt['price'], 2) . ' Birr)' : ''); ?>

                                            </span>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </div>
                                <?php endif; ?>
                            </div>
                            <div style="font-weight: 700; color: var(--gold-bright); font-size: 1.1rem;">
                                <?php echo e(number_format($item->subtotal, 2)); ?> Birr
                            </div>
                        </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </div>

                <div style="display: flex; flex-direction: column; gap: 0.5rem; font-size: 0.95rem; margin-bottom: 1.5rem;">
                    <div style="display: flex; justify-content: space-between;">
                        <span style="color: var(--text-cream-muted);">Subtotal</span>
                        <span><?php echo e(number_format($order->subtotal, 2)); ?> Birr</span>
                    </div>
                    <div style="display: flex; justify-content: space-between;">
                        <span style="color: var(--text-cream-muted);">Fulfillment</span>
                        <span><?php echo e(ucfirst($order->fulfillment_type)); ?> (<?php echo e($order->delivery_fee > 0 ? number_format($order->delivery_fee, 2) . ' Birr' : 'FREE'); ?>)</span>
                    </div>
                    <div style="display: flex; justify-content: space-between; font-size: 1.35rem; font-weight: 800; color: var(--gold-bright); padding-top: 0.75rem; border-top: 1px solid var(--border-subtle); margin-top: 0.5rem;">
                        <span>Total Due</span>
                        <span><?php echo e(number_format($order->total, 2)); ?> Birr</span>
                    </div>
                </div>

                <!-- In-Person Payment Reminder Card -->
                <div style="background: rgba(243, 198, 109, 0.1); border: 1px dashed var(--gold-border); border-radius: var(--radius-md); padding: 1.1rem 1.3rem; margin-bottom: 1.5rem;">
                    <div style="display: flex; align-items: center; gap: 0.5rem; color: var(--gold-bright); font-weight: 700; font-size: 0.95rem; margin-bottom: 0.4rem;">
                        <span>💵</span> Pay in Person With Order ID
                    </div>
                    <p style="font-size: 0.88rem; color: var(--text-cream-soft); margin: 0; line-height: 1.5;">
                        <?php if($order->fulfillment_type === 'pickup'): ?>
                            Bring your Order Reference <strong style="color: var(--cheddar-bright);">#<?php echo e($order->order_reference); ?></strong> to the pickup counter to settle <?php echo e(number_format($order->total, 2)); ?> Birr in store.
                        <?php else: ?>
                            Present your Order Reference <strong style="color: var(--cheddar-bright);">#<?php echo e($order->order_reference); ?></strong> to your delivery courier to pay <?php echo e(number_format($order->total, 2)); ?> Birr in cash upon arrival.
                        <?php endif; ?>
                    </p>
                </div>

                <?php if($order->fulfillment_type === 'delivery' && $order->delivery_address): ?>
                    <div style="background: var(--bg-surface); padding: 1.2rem; border-radius: var(--radius-md); border: 1px solid var(--border-subtle); margin-top: 1.5rem;">
                        <strong style="display: block; font-size: 0.85rem; color: var(--gold-bright); text-transform: uppercase; margin-bottom: 0.3rem;">📍 Delivery Destination</strong>
                        <div style="font-size: 0.95rem;"><?php echo e($order->delivery_address); ?> <?php echo e($order->delivery_apartment ? '(' . $order->delivery_apartment . ')' : ''); ?></div>
                        <div style="font-size: 0.85rem; color: var(--text-cream-muted);"><?php echo e($order->delivery_city); ?></div>
                        <?php if($order->delivery_notes): ?>
                            <div style="font-size: 0.82rem; color: var(--text-dim); margin-top: 0.4rem;">Note: <?php echo e($order->delivery_notes); ?></div>
                        <?php endif; ?>
                    </div>
                <?php endif; ?>
            </div>

            <!-- Right Panel: Live Kitchen Audit Timeline & Support -->
            <div style="display: flex; flex-direction: column; gap: 2rem;">
                <!-- Live Kitchen History -->
                <div class="tracker-card-panel">
                    <h3><span>⏱️</span> Kitchen Progress Log</h3>
                    <ul class="audit-history-list" id="tracker-audit-history">
                        <?php $__currentLoopData = $order->statusHistories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $history): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <li class="audit-item">
                                <div class="audit-dot"></div>
                                <div class="audit-time">
                                    <?php echo e($history->created_at->format('h:i A')); ?>

                                    <?php if($history->staff): ?>
                                        • <?php echo e($history->staff->name); ?>

                                    <?php endif; ?>
                                </div>
                                <div class="audit-note">
                                    <?php echo e($history->note ?? 'Order updated to ' . ucfirst($history->to_status)); ?>

                                </div>
                            </li>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </ul>
                </div>

                <!-- WhatsApp Support Card -->
                <div class="tracker-card-panel" style="background: radial-gradient(circle at 100% 0%, rgba(37, 211, 102, 0.15) 0%, var(--bg-card) 70%);">
                    <h3><span>💬</span> Need Assistance?</h3>
                    <p style="font-size: 0.92rem; color: var(--text-cream-soft); margin-bottom: 1.2rem;">
                        Have questions about your order or special dietary requirements? Reach our dispatch team directly on WhatsApp.
                    </p>
                    <a href="<?php echo e($order->whatsapp_link); ?>" target="_blank" rel="noopener noreferrer" class="btn btn-whatsapp btn-block">
                        <span>💬 Message Support on WhatsApp</span>
                    </a>
                </div>
            </div>
        </div>
    <?php endif; ?>
</div>

<?php if($isVerified): ?>
<?php $__env->startPush('scripts'); ?>
<script src="<?php echo e(asset('js/tracker.js')); ?>"></script>
<script>
document.addEventListener('DOMContentLoaded', () => {
    // Initialize McDonald's real-time tracker auto-polling
    new OrderTracker(
        "<?php echo e($order->order_reference); ?>",
        "<?php echo e($order->status); ?>",
        <?php echo e($order->timeline_step); ?>

    );
});
</script>
<?php $__env->stopPush(); ?>
<?php endif; ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\Users\Temeb\Desktop\lamri\resources\views/pages/track.blade.php ENDPATH**/ ?>