<?php $__env->startSection('title', $product->name . ' — The Cheddarloin'); ?>

<?php $__env->startSection('content'); ?>
<div class="container" style="padding-top: 3.5rem; padding-bottom: 5rem;">
    <!-- Breadcrumb -->
    <div style="margin-bottom: 2rem; font-size: 0.9rem; color: var(--text-cream-muted);">
        <a href="<?php echo e(route('home')); ?>">Home</a> &rarr; 
        <a href="<?php echo e(route('menu')); ?>">Menu</a> &rarr; 
        <a href="<?php echo e(route('menu', ['category' => $product->category->slug])); ?>"><?php echo e($product->category->name); ?></a> &rarr; 
        <span style="color: var(--text-cream);"><?php echo e($product->name); ?></span>
    </div>

    <div style="display: grid; grid-template-columns: 1fr 1.15fr; gap: 3.5rem; align-items: start;">
        <!-- Product Image -->
        <div>
            <div style="border-radius: var(--radius-xl); overflow: hidden; border: 1px solid var(--border-subtle); box-shadow: var(--shadow-lg); background: var(--bg-card);">
                <img src="<?php echo e($product->image_url); ?>" alt="<?php echo e($product->name); ?>" style="width: 100%; height: 460px; object-fit: cover;">
            </div>

            <div style="display: grid; grid-template-columns: repeat(3, 1fr); gap: 1rem; margin-top: 1.5rem;">
                <div style="background: var(--bg-surface); padding: 1rem; border-radius: var(--radius-md); text-align: center; border: 1px solid var(--border-subtle);">
                    <div style="font-size: 0.8rem; color: var(--text-cream-muted);">Prep Time</div>
                    <div style="font-weight: 700; color: var(--gold-bright); font-size: 1.1rem;">~<?php echo e($product->prep_time_minutes); ?> mins</div>
                </div>
                <div style="background: var(--bg-surface); padding: 1rem; border-radius: var(--radius-md); text-align: center; border: 1px solid var(--border-subtle);">
                    <div style="font-size: 0.8rem; color: var(--text-cream-muted);">Calories</div>
                    <div style="font-weight: 700; color: var(--gold-bright); font-size: 1.1rem;"><?php echo e($product->calories ?? 'N/A'); ?> kcal</div>
                </div>
                <div style="background: var(--bg-surface); padding: 1rem; border-radius: var(--radius-md); text-align: center; border: 1px solid var(--border-subtle);">
                    <div style="font-size: 0.8rem; color: var(--text-cream-muted);">Quality</div>
                    <div style="font-weight: 700; color: var(--cheddar-bright); font-size: 1.1rem;">100% Angus</div>
                </div>
            </div>
        </div>

        <!-- Product Details & Customization -->
        <div style="background: var(--bg-card); border: 1px solid var(--border-subtle); border-radius: var(--radius-xl); padding: 2.5rem;">
            <div style="display: flex; gap: 0.6rem; margin-bottom: 0.8rem;">
                <span class="badge badge-cheddar"><?php echo e($product->category->name); ?></span>
                <?php if($product->badge): ?>
                    <span class="badge badge-gold"><?php echo e($product->badge); ?></span>
                <?php endif; ?>
            </div>

            <h1 style="font-size: 2.2rem; margin-bottom: 0.8rem;"><?php echo e($product->name); ?></h1>
            <p style="font-size: 1.05rem; color: var(--text-cream-soft); line-height: 1.6; margin-bottom: 1.8rem;">
                <?php echo e($product->description); ?>

            </p>

            <div style="display: flex; align-items: baseline; gap: 1rem; padding-bottom: 1.5rem; border-bottom: 1px solid var(--border-subtle); margin-bottom: 2rem;">
                <span style="font-size: 0.9rem; color: var(--text-cream-muted);">Base Price:</span>
                <span style="font-size: 2rem; font-weight: 800; font-family: var(--font-heading); color: var(--gold-bright);" id="detail-base-price"><?php echo e(number_format($product->price, 2)); ?> Birr</span>
            </div>

            <!-- Customizations -->
            <form id="product-detail-form">
                <input type="hidden" id="detail-product-id" value="<?php echo e($product->id); ?>">
                <input type="hidden" id="detail-product-name" value="<?php echo e($product->name); ?>">
                <input type="hidden" id="detail-product-base" value="<?php echo e($product->price); ?>">
                <input type="hidden" id="detail-product-image" value="<?php echo e($product->image_url); ?>">

                <?php $__currentLoopData = $product->options; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $option): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div class="option-group" data-option-id="<?php echo e($option->id); ?>" data-option-name="<?php echo e($option->name); ?>" style="margin-bottom: 1.8rem;">
                        <div class="option-group-title">
                            <span><?php echo e($option->name); ?></span>
                            <?php if($option->is_required): ?>
                                <span class="badge badge-cheddar" style="font-size: 0.68rem;">Required</span>
                            <?php else: ?>
                                <span style="font-size: 0.78rem; color: var(--text-dim);">Optional</span>
                            <?php endif; ?>
                        </div>

                        <?php $__currentLoopData = $option->values; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $val): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <label class="option-item-row">
                                <div class="option-label-info">
                                    <input type="<?php echo e($option->type === 'radio' ? 'radio' : 'checkbox'); ?>"
                                           name="detail_opt_<?php echo e($option->id); ?>"
                                           value="<?php echo e($val->id); ?>"
                                           data-price="<?php echo e($val->price); ?>"
                                           data-val-name="<?php echo e($val->name); ?>"
                                           <?php echo e($val->is_default ? 'checked' : ''); ?>>
                                    <span><?php echo e($val->name); ?></span>
                                </div>
                                <span class="badge badge-gold" style="font-size: 0.75rem;">
                                    <?php echo e($val->price > 0 ? '(+' . number_format($val->price, 2) . ' Birr)' : 'Included'); ?>

                                </span>
                            </label>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                <!-- Quantity & Add to Cart -->
                <div style="display: flex; align-items: center; gap: 1.5rem; margin-top: 2rem; padding-top: 1.5rem; border-top: 1px solid var(--border-subtle);">
                    <div class="qty-control" style="background: var(--bg-surface); padding: 0.3rem;">
                        <button type="button" class="qty-btn" id="detail-qty-minus">-</button>
                        <span class="qty-value" id="detail-qty-value" style="padding: 0 0.8rem;">1</span>
                        <button type="button" class="qty-btn" id="detail-qty-plus">+</button>
                    </div>

                    <button type="button" class="btn btn-primary btn-lg" id="detail-add-btn" style="flex: 1;">
                        Add to Cart • <span id="detail-total-price"><?php echo e(number_format($product->price, 2)); ?> Birr</span>
                    </button>
                </div>
            </form>
        </div>
    </div>
</div>

<?php $__env->startPush('scripts'); ?>
<script>
document.addEventListener('DOMContentLoaded', () => {
    let quantity = 1;
    const basePrice = parseFloat(document.getElementById('detail-product-base').value);
    const form = document.getElementById('product-detail-form');
    const qtyValEl = document.getElementById('detail-qty-value');
    const totalEl = document.getElementById('detail-total-price');

    function calculateTotal() {
        let optionsPrice = 0;
        form.querySelectorAll('input:checked').forEach(input => {
            optionsPrice += parseFloat(input.dataset.price) || 0;
        });
        const unit = basePrice + optionsPrice;
        const total = unit * quantity;
        totalEl.textContent = Cart.formatPrice(total);
        return { unit, total };
    }

    document.getElementById('detail-qty-minus').addEventListener('click', () => {
        if (quantity > 1) {
            quantity--;
            qtyValEl.textContent = quantity;
            calculateTotal();
        }
    });

    document.getElementById('detail-qty-plus').addEventListener('click', () => {
        if (quantity < 50) {
            quantity++;
            qtyValEl.textContent = quantity;
            calculateTotal();
        }
    });

    form.querySelectorAll('input').forEach(input => {
        input.addEventListener('change', calculateTotal);
    });

    document.getElementById('detail-add-btn').addEventListener('click', () => {
        const selectedOptions = [];
        form.querySelectorAll('.option-group').forEach(group => {
            const optName = group.dataset.optionName;
            group.querySelectorAll('input:checked').forEach(input => {
                selectedOptions.push({
                    option_name: optName,
                    value_id: parseInt(input.value),
                    choice: input.dataset.valName,
                    price: parseFloat(input.dataset.price) || 0
                });
            });
        });

        const product = {
            id: parseInt(document.getElementById('detail-product-id').value),
            name: document.getElementById('detail-product-name').value,
            price: basePrice,
            image_url: document.getElementById('detail-product-image').value
        };

        Cart.addItem(product, quantity, selectedOptions);
    });
});
</script>
<?php $__env->stopPush(); ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\Users\Temeb\Desktop\lamri\resources\views/pages/product-detail.blade.php ENDPATH**/ ?>